let
    Source = Csv.Document(
        File.Contents("C:\YOUR_PATH\road_accidents.csv"),
        [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]
    ),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders,{
        {"State", type text},
        {"Year", Int64.Type},
        {"Area_Type", type text},
        {"Accident_Count", Int64.Type},
        {"Deaths", Int64.Type},
        {"Injuries", Int64.Type}
    }),
    CleanRows = Table.SelectRows(ChangedTypes, each [State] <> null and [Year] <> null),
    TrimText = Table.TransformColumns(CleanRows,{
        {"State", Text.Trim, type text},
        {"Area_Type", Text.Trim, type text}
    })
in
    TrimText
