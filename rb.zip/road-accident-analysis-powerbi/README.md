# Road Accident Analysis Dashboard (Power BI)

Power BI starter files for an India road-accident dashboard. The original `.pbix` report cannot be recreated from a CV description alone; this folder contains a Power Query template and DAX measures to build a reproducible report.

## Expected source columns
`State`, `Year`, `Area_Type` (Rural/Urban), `Accident_Count`, `Deaths`, `Injuries`.

Use an official or otherwise properly licensed dataset and record its source, date range and definitions here. Do not present sample or synthetic values as official statistics.

## Build in Power BI Desktop
1. Import your CSV using **Get Data → Text/CSV**.
2. Open **Transform data → Advanced Editor** and adapt `Power_Query_M.m` to your file path and actual column names.
3. Rename the loaded table to `RoadAccidents` or update the table name in `Measures.dax`.
4. Create the measures in `Measures.dax`.
5. Add cards for Total Accidents, Total Deaths and Total Injuries.
6. Add charts by State and Year, a Rural-vs-Urban comparison, and a State map if your dataset includes suitable geographic fields.
7. Add slicers for Year, State and Area_Type; save the finished `.pbix` in this repository.

## Suggested visuals
- KPI cards: accidents, deaths, injuries
- Line chart: accidents by year
- Bar chart: accidents by state
- Donut/stacked bar: rural vs urban
- Filled map: state-wise accident counts

**Note:** These are starter assets, not your original PBIX or verified project data. Confirm field names and measures against the dataset you actually used.
